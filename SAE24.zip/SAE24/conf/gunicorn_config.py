command = '/home/frigiel/.local/bin/gunicorn'
pythonpath = '/home/frigiel/SAE24'
bind = '10.252.4.61:8000'
workers = 3
